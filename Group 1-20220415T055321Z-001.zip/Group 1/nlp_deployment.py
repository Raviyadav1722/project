# -*- coding: utf-8 -*-
"""
Created on Tue Mar 15 11:00:12 2022

@author: naga1
"""
import pickle
import streamlit as st
import nltk
from nltk.tokenize import RegexpTokenizer
from nltk.stem import PorterStemmer
import string
import re
from nltk.corpus import stopwords
import numpy as np
import json


ps= PorterStemmer()

def lower(Tweets:str):
    Tweets = Tweets.lower()
    return Tweets

def textCleaning(Tweets):
    op = re.sub(r'@[A-Za-z0-9]+', ' ', Tweets) #removed @mentions
    op = re.sub(r'#[A-Za-z0-9]+',' ', op) #removing the # symbol
    op = re.sub('https://[a-zA-z0-9/\.]+',' ',op) #Removing hyperlink
    op = re.sub('[^a-zA-Z0-9]+',' ',op)#Removing emojis
    op = re.sub(r'\b\d+\b',' ',op)# removing numbers
    op = re.sub(r'\b\d+(th)?\b',' ',op)
    op = re.sub('\s+',' ',op)#removing unwanted spaces
    op = re.sub(r' s ',' ',op)
    op = re.sub('\w*\d\w*',' ',op)# removing words containing numbers
    return op

def remove_stopwords(Tweets):
    Tweets = [word for word in Tweets if word not in stopwords.words('english')]
    return Tweets

def stem_text(Tweets):
    Tweets = [ps.stem(word) for word in Tweets]
    return Tweets

tfid = pickle.load(open('tfidif.pkl','rb'))
model = pickle.load(open('model.pkl','rb'))

st.title('Twitter Disaster Classifier')

input_tweet = st.text_input('Enter the Tweet')

if st.button('predict'):

    #1. Preprocess
    
    lowered_tweet = lower(input_tweet)
    cleaned_text = textCleaning(lowered_tweet)
    
    # applying tokenization technique
    
    token = RegexpTokenizer(r'\w+')
    text_token = token.tokenize(cleaned_text)
    
    # removal of stopwords
    
    removed_stopwords_text = remove_stopwords(text_token)
    
    #Stemming
    
    stemmed_text = stem_text(removed_stopwords_text)
    
    
    #2. Vectorize
    
    tfidif_vec_text = tfid.transform([stemmed_text])
    
    #3. predict
    
    result = model.predict(tfidif_vec_text)
    
    #4. Display
    
    if result ==1:
        st.header('This is a DISASTROUS news')
    else:
        st.header('This is not a disaster news')